from task import Task

class Section:
    def __init__(self, name: str):
        self.name = name
        self.task_dict = {}


    def add_task(self, new_task: Task):
        if not new_task in Task.tasks:
            Task.tasks.append(new_task)
            self.task_dict[new_task] = Task.details(new_task)
            return f"Task {Task.details(new_task)} is added to the section"
        else:
            return f"Task is already in the section {self.name}"

    def complete_task(self, task_name: str):
        if task_name in Task.tasks:
            Task.completed = True
            Task.completed_tasks.append(task_name)
            return f"Completed task {task_name}"
        else:
            return f"Could not find task with the name {task_name}"

    def clean_section(self):
        for ts in Task.completed_tasks:
            if ts in self.task_dict:
                del self.task_dict[ts]
            if ts in Task.tasks:
                Task.tasks.remove(ts)
                return f"Cleared {len(Task.completed_tasks)} tasks."
        if len(Task.completed_tasks) == 0:
            return "Cleared 0 tasks."


    def view_section(self):
        result = ""
        result += f"Section {self.name}:\n"
        for key, value in self.task_dict.items():
            result += f"{value}\n"
        return result


task = Task("Make bed", "27/05/2020")
print(task.change_name("Go to University"))
print(task.change_due_date("28.05.2020"))
task.add_comment("Don't forget laptop")
print(task.edit_comment(0, "Don't forget laptop and notebook"))
print(task.details())
section = Section("Daily tasks")
print(section.add_task(task))
second_task = Task("Make bed", "27/05/2020")
section.add_task(second_task)
print(section.clean_section())
print(section.view_section())